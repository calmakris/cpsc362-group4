import chess_Engine


if __name__ == '__main__':
	Chess = chess_Engine.Chess_Board()
	Chess.start_game()